# Focal Lock
Addon for Blender to maintain a camera's focal length/distance ratio.

See promotion video here: https://youtu.be/db8TEAO8qDM

Directories *com* and *imp* in this directory are copied - with very minor changes - from their respective counterparts on [Khronos repository](https://github.com/KhronosGroup/glTF-Blender-IO/tree/master/addons/io_scene_gltf2/blender), set at [commit 709630548cdc184af6ea50b2ff3ddc5450bc0af3](https://github.com/KhronosGroup/glTF-Blender-IO/commit/709630548cdc184af6ea50b2ff3ddc5450bc0af3) (Blender 2.93).

Licensed under [Apache Version 2](https://www.apache.org/licenses/LICENSE-2.0), see [LICENSE.txt](https://github.com/sketchfab/blender-plugin/blob/master/LICENSE.txt).


